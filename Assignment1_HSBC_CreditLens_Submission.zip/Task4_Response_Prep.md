# Task 4 - Response Preparation

## Why did you choose HSBC?

HSBC is a credible entity because it has material operations in both Hong Kong and the United States. A jurisdiction-aware tool is more convincing when the selected institution actually faces cross-border compliance requirements.

## Why did you use synthetic data?

Real retail credit decision data is confidential and not available for this assignment. Synthetic data allows the prototype to demonstrate the regulatory mechanics without using customer data. The limitation is acknowledged throughout the submission.

## Why logistic regression rather than a more complex AI model?

The assignment is about jurisdiction-aware RegTech design, not predictive model competition. Logistic regression gives enough model behavior to demonstrate credit scoring, adverse-action reasons, fairness metrics, and drift monitoring while remaining explainable.

## What is the most important jurisdiction difference?

The US output must support specific adverse-action explanations and fair lending screening. Hong Kong output is more governance-oriented: proportionality, human oversight, privacy, consumer credit data handling, and ongoing monitoring.

## What would you add with more time?

I would add real model documentation workflows, versioned rule libraries, role-based access control, legal sign-off tracking, integration with model validation evidence, and richer explainability methods such as SHAP or LIME.
